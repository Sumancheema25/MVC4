﻿using System;

namespace mvc4.Models
{
    public class Movie
    {
        public int MovieId { get; set; }

        public string Name { get; set; }

        public string Year { get; set; }

        public string Genre { get; set; }

        internal object Where(Func<object, bool> p)
        {
            throw new NotImplementedException();
        }
    }
}
