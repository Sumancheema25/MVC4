﻿using mvc4.Models;
using System.Collections.Generic;
using System.Linq;

namespace mvc4
{
    public class MovieData
    {
        public static List<Movie> GetMoviesData()
        {
            List<Movie> movies = new List<Movie>();
            Movie m = new Movie()
            {
                MovieId = 1,
                Name = "Barffi",
                Year = "2017",
                Genre = "Romantic"
            };

            Movie m1 = new Movie()
            {
                MovieId = 2,
                Name = "The Matrix",
                Year = "1999",
                Genre = "Fiction"
            };

            Movie m2 = new Movie()
            {
                MovieId = 3,
                Name = "Ae dil hai mushkil",
                Year = "2016",
                Genre = "Romantic"
            };

            Movie m3 = new Movie()
            {
                MovieId = 4,
                Name = "The Dark Knight",
                Year = "2007",
                Genre = "Action"
            };

            Movie m4 = new Movie()
            {
                MovieId = 5,
                Name = "Sandeep Singh",
                Year = "2018",
                Genre = "Reality Based"
            };
            movies.Add(m);
            movies.Add(m1);
            movies.Add(m2);
            movies.Add(m3);
            movies.Add(m4);
            return movies;
        }

        public static Movie GetFilteredMovie( int id)
        {
           return GetMoviesData().Where(x => x.MovieId == id).FirstOrDefault();
        }
        public static List<Movie> AddMovie(Movie model)
        {
            var obj = model;
            List<Movie> movies = MovieData.GetMoviesData();
            movies.Add(obj);
            return movies;
        }
        public static List<Movie> EditMovie(Movie model)
        {
            var obj = model;
            List<Movie> movies = MovieData.GetMoviesData();
            Movie movie = movies.Where(x => x.MovieId == obj.MovieId).Select(x => { x = obj; return x; }).FirstOrDefault();
            movies.RemoveAll(x => x.MovieId == model.MovieId);
            movies.Add(movie);
            return movies.OrderBy(x => x.MovieId).ToList();
        }
    }
}
